package game;

/*
 * Functional interface used to maipulate Points
 * 
 * @author: aminahasgharali
 */
public interface PointManipulator {
	
	public Point manipulate(int index);

}
